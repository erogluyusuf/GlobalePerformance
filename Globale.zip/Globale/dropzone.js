// app.js
window.addEventListener('load', function() {
  file()
});

function file(){
  function findLatestFile() {
    const fileInput = document.getElementById('fileInput');
    const files = fileInput.files;

    if (files.length > 0) {
        const latestFile = Array.from(files).reduce((a, b) => {
            return b.lastModified > a.lastModified ? b : a;
        });

        console.log('En son eklenen dosya:', latestFile.name);
    } else {
        console.log('Herhangi bir dosya seçilmedi.');
    }
}
  
}