window.addEventListener('load', function() {
  map()
  checkRangeValue()
  casioG()
  codeP()
});
document.addEventListener("DOMContentLoad", typeWriter, false);

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.command === "executeCommand") {
      // Burada komutu çalıştırın ve sonucu alın
      // Örnek olarak, basit bir komutu çalıştırma:
      chrome.runtime.sendNativeMessage("your_host_app", { command: "your_command" }, function(response) {
        sendResponse({ result: response });
      });
      // Not: "your_host_app" ve "your_command" kendi durumunuza göre değiştirilmelidir.
      return true;  // sendResponse'in asenkron olduğunu belirtmek için
    }
  });
  



  

  function map() {
    if ('geolocation' in navigator) {
      navigator.permissions.query({ name: 'geolocation' }).then(function(permissionStatus) {
        if (permissionStatus.state === 'granted') {
          navigator.geolocation.getCurrentPosition(function(position) {
            var latitude = position.coords.latitude;
            var longitude = position.coords.longitude;
            document.getElementById("map").title = "Enlem: " + latitude + ", Boylam: " + longitude;
            console.log("Latitude:", latitude);
            console.log("Longitude:", longitude);
          }, function(error) {
            console.error("Error getting geolocation:", error.message);
          });
        } else if (permissionStatus.state === 'prompt') {
          console.log("Geolocation permission is pending. Waiting for user interaction.");
        } else {
          // Geolocation izni kullanıcı tarafından reddedildiğinde SweetAlert ile bildirim yap

          console.log("Geolocation permission denied by the user.");
        }
      });
    } else {
      console.log("Geolocation API not supported.");
    }
  }





  function checkRangeValue() {
    // Range input elementini seçin
    var rangeInput = document.getElementById("volumes");
  
    // Range input değerini kontrol edin
    var currentValue = rangeInput.value;
  
    // Eğer değer 0 ise, gerekli işlemleri gerçekleştirin
    if (parseInt(currentValue) === 0) {
      document.getElementById("Voff").style.display="block";
      document.getElementById("Von").style.display="none";  
    } else {
      document.getElementById("Von").style.display="block"; 
      document.getElementById("Voff").style.display="none"; 
    }
  }        setInterval(checkRangeValue, 1000);



 













/*      Promt girişi termianl          */


document.addEventListener("DOMContentLoaded", typeWriter, false);

var typeWriter = function (selector, type, interval) {

    var el = document.querySelectorAll(selector), // Getting elements in the DOM
        i = 0,
        len = el.length, // Length of element on the page
        list = [], // List of elements on the page in the DOM
        a,
        all,
        text,
        start,
        end,
        nextText,
        sectionId = selector.replace(/^#/, ''),
        targetSection = document.getElementById(sectionId),
        sections = document.getElementsByTagName("section")[0],
        targetSiblings = [].slice.call(sections.parentNode.children).filter(function(v) { return v !== targetSection }),
        cmd = document.querySelector(".command"),
        clear;

    for (; i < len; i++) {

        list.push(el[i]); // Pushing the element in the list array
    }

    for (a in list) {

        all = list[a]; // List of all element
        text = all.innerHTML; // InnerHTML of the elements 
        start = 0; // Start index of the text in the elements 
        end = 0; // End index of the text in the elements


        //Setting the default interval to 100 when interval is not set by the user
        if (typeof interval === "undefined") {

            interval = 100;

        }

        if (arguments[1] === "true") {

                setTimeout(function() {
                        targetSection.classList.add("open");
                }, 200);

                for(var i = 0;i < targetSiblings.length;i++) {
                        targetSiblings[i].classList.remove("open");
                }

            clear = setInterval(function () { // Animation start
                var newText = text.substr(start, end);

                all.innerHTML = newText;

                end = end + 1; //loops through the text in the element

                if (newText === text) {

                    clearInterval(clear); // Animation end
                    cmd.classList.add("open");
                    input.focus();

                }

            }, interval);

        }

        return all;

    }

}

var input = document.querySelector("#pr"),
        block = document.getElementsByTagName("section");

window.onload = function() {
        typeWriter("#home","true",10);

        var sectionArray = [];
        for(var i = 0;i < block.length;i++) {
                sectionArray.push(block[i].id);
        }
        //console.log(sectionArray);

        input.addEventListener('keyup', function(e) {
                if((e.keyCode || e.which) == 13) {// ENTER key pressed
                        var targetValue = input.value.replace(/\s/g, '').toLowerCase();
                        var destination = "#" + targetValue;
                        typeWriter(destination,"true",10);
                        input.value = "";

                        if(sectionArray.includes(targetValue) == false) {
                                typeWriter("#error","true",10);
                        }
                }
        });
};
document.addEventListener("DOMContentLoaded", function () {
    var typeWriter = function (selector, type, interval) {
      var el = document.querySelectorAll(selector),
        i = 0,
        len = el.length,
        list = [],
        a,
        all,
        text,
        start,
        end,
        nextText,
        sectionId = selector.replace(/^#/, ''),
        targetSection = document.getElementById(sectionId),
        sections = document.getElementsByTagName("section")[0],
        targetSiblings = [].slice.call(sections.parentNode.children).filter(function (v) { return v !== targetSection }),
        cmd = document.querySelector(".command"),
        clear;

      for (; i < len; i++) {
        list.push(el[i]);
      }

      for (a in list) {
        all = list[a];
        text = all.innerHTML;
        start = 0;
        end = 0;

        if (typeof interval === "undefined") {
          interval = 100;
        }

        if (arguments[1] === "true") {
          setTimeout(function () {
            targetSection.classList.add("open");
          }, 200);

          for (var i = 0; i < targetSiblings.length; i++) {
            targetSiblings[i].classList.remove("open");
          }

          clear = setInterval(function () {
            var newText = text.substr(start, end);

            all.innerHTML = newText;

            end = end + 1;

            if (newText === text) {
              clearInterval(clear);
              cmd.classList.add("open");
              input.focus();
            }
          }, interval);
        }
        return all;
      }
    };

    var input = document.querySelector("#pr"),
      block = document.getElementsByTagName("section");

    window.onload = function () {
      typeWriter("#home", "true", 10);

      var sectionArray = [];
      for (var i = 0; i < block.length; i++) {
        sectionArray.push(block[i].id);
      }

      input.addEventListener('keyup', function (e) {
        if ((e.keyCode || e.which) == 13) { // ENTER key pressed
          var targetValue = input.value.replace(/\s/g, '').toLowerCase();
          var destination = "#" + targetValue;
          typeWriter(destination, "true", 10);
          input.value = "";

          if (sectionArray.includes(targetValue) == false) {
            typeWriter("#error", "true", 10);
          }
        }
      });
    };
  });

var input = document.querySelector("#pr"),
	block = document.getElementsByTagName("section");

window.onload = function() {
	typeWriter("#home","true",10);

	var sectionArray = [];
	for(var i = 0;i < block.length;i++) {
		sectionArray.push(block[i].id);
	}
	//console.log(sectionArray);

	input.addEventListener('keyup', function(e) {
		if((e.keyCode || e.which) == 13) {// ENTER key pressed
			var targetValue = input.value.replace(/\s/g, '').toLowerCase();
			var destination = "#" + targetValue;
			typeWriter(destination,"true",10);
			input.value = "";

			if(sectionArray.includes(targetValue) == false) {
				typeWriter("#error","true",10);
			}
		}
	});
};




document.addEventListener('DOMContentLoaded', function() {
  const firstElement = document.querySelector('#hide');
  firstElement.addEventListener('click', function() {
    if(document.getElementById('terminal').style.display == 'none'){
          document.getElementById('terminal').style.display = 'block';
    }else{
          document.getElementById('terminal').style.display = 'none';
    }

  });
});

document.addEventListener('DOMContentLoaded', function() {
  const firstElement = document.querySelector('#Bright');
  var terminalWindow = document.querySelector('.terminal-window');
  firstElement.addEventListener('click', function() {
    if( !terminalWindow.classList.contains('bright-animation') ){
      terminalWindow.classList.remove('bright-animationl');
      terminalWindow.classList.add('bright-animation');

    }else{
      terminalWindow.classList.remove('bright-animation');
      terminalWindow.classList.add('bright-animationl');
    }

  });
});

document.addEventListener('DOMContentLoaded', function() {
  const firstElement = document.querySelector('#small');
  firstElement.addEventListener('click', function() {
    if(document.getElementById('terminal').style.display == 'none'){
          document.getElementById('terminal').style.display = 'block';     
    }else{
      var terminalWindow =  document.getElementById('terminal-window');
      var erminalWindow =  document.getElementsByClassName('terminal-window');
          terminalWindow.style.minHeight = '30px';
          terminalWindow.style.height = "30px";

          document.getElementById('terminal').style.display = 'none';

    }

  });
});


