window.addEventListener('load', function() {
    buttonPOP()
   // updateSpanValue()

});
function buttonPOP(){
class Switch {
    constructor(selector, { highlightClass = "c-switch__highlight", activeClass = "is-active" } = {}) {
      this.activeClass = activeClass;
      this.element = document.querySelector(selector);
      this.buttons = this.element.querySelectorAll("button");
      this.highlight = this.element.querySelector(`.${highlightClass}`);
      this.activeBtn = this.element.querySelector(`button.${this.activeClass}`);
  
      if (!this.activeBtn) {
        this.activeBtn = this.buttons[0];
        this.activeBtn.classList.add(this.activeClass);
      }
  
      this._highlight();
      this._addEvents();
    }
  
    _highlight() {
      const w = this.activeBtn.offsetWidth;
      const x = this.activeBtn.offsetLeft;
  
      this.highlight.style.width = `${w}px`;
      this.highlight.style.transform = `translateX(${x}px)`;
    }
  
    _dispatchEvent() {
      this.element.dispatchEvent(
        new CustomEvent("change", { detail: this.activeBtn.dataset.value })
      );
    }
  
    _addEvents() {
      Array.from(this.buttons).forEach(btn =>
        btn.addEventListener("click", e => {
          if (this.activeBtn === e.target) return;
  
          this.activeBtn.classList.remove(this.activeClass);
          this.activeBtn = e.target;
          this.activeBtn.classList.add(this.activeClass);
  
          this._highlight();
          this._dispatchEvent();
        })
      );
    }
  }
  
  const mySwitch = new Switch(".c-switch");
  
  mySwitch.element.addEventListener("change", e => console.log(e.detail));
}






document.addEventListener('DOMContentLoaded', function() {
  const firstElement = document.querySelector('.first');
  const secondElement = document.querySelector('.second');
  const thirdElement = document.querySelector('.third');
  const fourthElement = document.querySelector('.fourth');
  const fileElement = document.querySelector('.file');
  const displaycontrol = document.getElementById('displaycontrol')

  // İlk butona tıklanınca
  firstElement.addEventListener('click', function() {
    document.getElementById('welcome').style.display = 'block';
    document.getElementById('global').style.display = 'none';
    document.getElementById('WinSAT').style.display = 'none';
    document.getElementById('share').style.display = 'none';
  });

  // İkinci butona tıklanınca
  secondElement.addEventListener('click', function() {
    runSpeedTest()
    document.getElementById('welcome').style.display = 'none';
    document.getElementById('global').style.display = 'block';
    document.getElementById('WinSAT').style.display = 'none';
    document.getElementById('share').style.display = 'none';
  });

  // Üçüncü butona tıklanınca
  thirdElement.addEventListener('click', function() {
    document.getElementById('welcome').style.display = 'none';
    document.getElementById('global').style.display = 'none';
    document.getElementById('WinSAT').style.display = 'block';
    document.getElementById('share').style.display = 'none';
  });
    // dördüncü butona tıklanınca
    fourthElement.addEventListener('click', function() {
      document.getElementById('welcome').style.display = 'none';
      document.getElementById('global').style.display = 'none';
      document.getElementById('WinSAT').style.display = 'none';
      document.getElementById('share').style.display = 'block';
    });
    fileElement.addEventListener('click', function() {
    //  document.getElementById('welcome').style.display = 'none';

    });
  /*displaycontrol.addEventListener('click', function() {
    if(document.getElementById('DisplayLight').style.display == 'block'){
      document.getElementById('DisplayLight').style.display = 'none';
    }else{
      document.getElementById('DisplayLight').style.display = 'block'
    }
    
  });*/
  //eğer bu yprum satırı açılırsa ses ve ışık ayarlarına erişim sağlanır.başka bir değişikliğe gerek kalmaz javascript ile doğrudam erişim sağlanmadığı için yarım kaldı.
});

/*

setInterval(updateSpanValue, 500);
setInterval(changeVolume, 500);
function updateSpanValue() {
  // Input elementini seç
  var rangeInput = document.getElementById("volumes");
  
  // Span elementini seç
  var spanValue = document.getElementById("volumeValue");
  
  // Input değerini al ve span içeriğine yaz
  spanValue.textContent = rangeInput.value;
}




function changeVolume() {
  const audioContext = new (window.AudioContext || window.webkitAudioContext)();
  const gainNode = audioContext.createGain();
  
  navigator.mediaDevices.getUserMedia({ audio: true })
    .then((stream) => {
      const mediaStreamSource = audioContext.createMediaStreamSource(stream);
      mediaStreamSource.connect(gainNode);
      gainNode.connect(audioContext.destination);
    })
    .catch((err) => {
      console.error('Error accessing microphone:', err);
    });
  
  // Ses seviyesini kontrol etmek için input olayını dinle
  const volumeInput = document.getElementById('volumes');
  volumeInput.addEventListener('input', () => {
    const volumeValue = volumeInput.value / 100;
    gainNode.gain.value = volumeValue;
  });
  
  // Ses seviyesini varsayılan değerle başlat
  const initialVolume = volumeInput.value / 100;
  gainNode.gain.value = initialVolume;
  
}*/

