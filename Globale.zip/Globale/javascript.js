


window.addEventListener('load', function() {
    // Buraya sayfa yüklendiğinde yapılması istenen işlemleri ekleyebilirsiniz
    console.log('Sayfa yüklendi!');
    Os();
    OsURL();
});

var URL;
function Os() {
    var isletimSistemi = navigator.platform;
    console.log(isletimSistemi);
    if (isletimSistemi === 'Win32') {
        URL = "C:\\Windows\\Performance\\WinSAT\\DataStore\\WinSAT.xml";
        findRoot();
        system(); 
    } else if (isletimSistemi === 'MacIntel') {
        URL = "/Library/system_profiler.xml";
        findRootMAC();
        systemMAC(); 
    } else if(isletimSistemi === 'Linux'){
        URL = "/home/lshw.xml";
        findRootLinux();
        systemLinux(); 
    }else{
        alert("Upps! Upps! Unknown operating system.");
            var sourcePageElement = document.getElementById("source-Page");
            sourcePageElement.style.display = "none";
    }
    
    function OsURL(){
        if (URL==""){
            var sourcePageElement = document.getElementById("source-Page");
            sourcePageElement.style.display = "none";
        }
    }
    // URL değişkeni, işletim sistemine bağlı olarak doğru dosya yolunu içerir.
    console.log("File Path: " + URL);
}




/*      WİNDOWS OS      */
function findRoot() {
    var sourcePageElement = document.getElementById("source-Page");
    sourcePageElement.style.display = "block";
    // XML dosyasının URL'si
   var xmlURL = URL;
    // XMLHttpRequest nesnesini oluştur
    var xhr = new XMLHttpRequest();

    // GET isteği yap
    xhr.open('GET', xmlURL, true);

    // İsteği gönder
    xhr.send();

    // İstek tamamlandığında bu fonksiyon çalışacak
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // XML dosyasını işle
            var xmlDoc = xhr.responseXML;

            // XML içindeki tüm 'WinSAT' öğelerini seç

            

            var winSATElements = xmlDoc.getElementsByTagName('WinSAT');





            // Tablo gövdesini seç
            var tableBody = document.getElementById('tableBody');

            // Tek bir açılır menü düğmesi oluştur
            var button;
            if (!button) {
                button = document.createElement('button');
                button.innerHTML = 'More details';
            }


            // Her bir 'WinSAT' öğesi için döngü
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm çocukları al
                var children = winSATElements[i].children;

                // İçerik div'i oluştur
                var contentDiv = document.createElement('div');
                contentDiv.className = 'hidden';

                // Her bir çocuk için döngü
                for (var j = 0; j < children.length; j++) {
                    // Çocuğun tag ismini ve içeriğini al
                    var tagName = children[j].tagName;
                    var content = children[j].textContent;

                    // İçeriği maksimum 60 karaktere kısalt
                    if (content.length > 60) {
                        content = content.substring(0, 60) + '...';
                    }

                    // Etiket ve içeriği içeren bir paragraf oluştur
                    var paragraph = document.createElement('p');
                    paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                    // Paragrafı içerik div'ine ekle
                    contentDiv.appendChild(paragraph);

                    // Her bir çocuğun altındaki çocukları al
                    var nestedChildren = children[j].children;

                    // Her bir alt çocuk için döngü
                    for (var k = 0; k < nestedChildren.length; k++) {
                        // Alt çocuğun tag ismini ve içeriğini al
                        var nestedTagName = nestedChildren[k].tagName;
                        var nestedContent = nestedChildren[k].textContent;

                        // İçeriği maksimum 60 karaktere kısalt
                        if (nestedContent.length > 60) {
                            nestedContent = nestedContent.substring(0, 60) + '...';
                        }

                        // Alt çocuğu içeren bir paragraf oluştur
                        var nestedParagraph = document.createElement('p');
                        nestedParagraph.innerHTML = '<b> &nbsp &nbsp' + nestedTagName + ':</b> ' + nestedContent;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(nestedParagraph);

                        // Alt çocuğun altındaki çocukları al
                        var doubleNestedChildren = nestedChildren[k].children;

                        // Her bir double-alt çocuk için döngü
                        for (var m = 0; m < doubleNestedChildren.length; m++) {
                            // Double-alt çocuğun tag ismini ve içeriğini al
                            var doubleNestedTagName = doubleNestedChildren[m].tagName;
                            var doubleNestedContent = doubleNestedChildren[m].textContent;

                            // İçeriği maksimum 60 karaktere kısalt
                            if (doubleNestedContent.length > 60) {
                                doubleNestedContent = doubleNestedContent.substring(0, 60) + '...';
                            }

                            // Double-alt çocuğu içeren bir paragraf oluştur
                            var doubleNestedParagraph = document.createElement('p');
                            doubleNestedParagraph.innerHTML = '<b> &nbsp &nbsp &nbsp' + doubleNestedTagName + ':</b> ' + doubleNestedContent;

                            // Paragrafı içerik div'ine ekle
                            contentDiv.appendChild(doubleNestedParagraph);

                            // Double-alt çocuğun altındaki çocukları al
                            var tripleNestedChildren = doubleNestedChildren[m].children;

                            // Her bir triple-alt çocuk için döngü
                            for (var n = 0; n < tripleNestedChildren.length; n++) {
                                // Triple-alt çocuğun tag ismini ve içeriğini al
                                var tripleNestedTagName = tripleNestedChildren[n].tagName;
                                var tripleNestedContent = tripleNestedChildren[n].textContent;

                                // İçeriği maksimum 60 karaktere kısalt
                                if (tripleNestedContent.length > 60) {
                                    tripleNestedContent = tripleNestedContent.substring(0, 60) + '...';
                                }

                                // Triple-alt çocuğu içeren bir paragraf oluştur
                                var tripleNestedParagraph = document.createElement('p');
                                tripleNestedParagraph.innerHTML = '<b> &nbsp &nbsp &nbsp &nbsp' + tripleNestedTagName + ':</b> ' + tripleNestedContent;

                                // Paragrafı içerik div'ine ekle
                                contentDiv.appendChild(tripleNestedParagraph);
                            }
                        }
                    }
                }

                // Her 'WinSAT' öğesi için tek bir satır oluştur
                var row = tableBody.insertRow();
                var cell = row.insertCell(0);

                // Açılır menü düğmesini satıra ekle
                cell.appendChild(button.cloneNode(true));

                // Düğmeye tıklandığında içeriği göster/gizle
                cell.querySelector('button').addEventListener('click', function() {
                    contentDiv.classList.toggle('hidden');
                });

                // İçerik div'ini satıra ekle
                cell.appendChild(contentDiv);
            }
        }
    };
}


         // tableBody id'sine sahip elementi seç
         var tableBody = document.getElementById('tableBody');

         // tableBody'nin altındaki <tr> tag'larını seç
         var trElements = tableBody.getElementsByTagName('tr');
         
         // <tr> tag'larının sayısını al
         var rowCount = trElements.length;
         
         // Sayıyı alert ile göster
         alert('tableBody altındaki <tr> tag\'larının sayısı: ' + rowCount);

// Sayfa yüklendiğinde findRoot fonksiyonunu çağır
document.addEventListener('DOMContentLoaded', findRoot);





/* genel inceleme bitti özell */
function system() {
    var sourcePageElement = document.getElementById("source-Page");
    sourcePageElement.style.display = "block";
    var xmlURL = URL;
    //var xmlURL = 'WinSATP.xml';
    // XMLHttpRequest nesnesini oluştur
    var xhr = new XMLHttpRequest();

    // GET isteği yap
    xhr.open('GET', xmlURL, true);

    // İsteği gönder
    xhr.send();

    // İstek tamamlandığında bu fonksiyon çalışacak
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // XML dosyasını işle
            var xmlDoc = xhr.responseXML;

            // XML içindeki tüm 'WinSAT' öğelerini seç
            var winSATElements = xmlDoc.getElementsByTagName('WinSAT');

            // Her bir 'WinSAT' öğesi için döngü
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByTagName('System');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('system');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;

                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(paragraph);
                    }
                }
            }
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByTagName('Memory');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('memory');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;

                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(paragraph);
                    }
                }
            }
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByTagName('Monitors');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('Monitors');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;

                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(paragraph);
                    }
                }
            }
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByTagName('Graphics');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('Graphics');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;

                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(paragraph);
                    }
                }
            }
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByTagName('Disk');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('Disk');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;

                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(paragraph);
                    }
                }
            }
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByTagName('WinSPR');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('WinSPR');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;
                        var integerValue = parseInt(content, 10);
                        var WinSPR = document.getElementById('WinSPR');
                        if (integerValue > 7.5) {
                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + '<b id="green">' + integerValue + '</b>';
                        } else {
                            var paragraph = document.createElement('p');
                            paragraph.innerHTML = '<b>' + tagName + ':</b> ' + '<b id="red">' + integerValue + '</b>';
                        }
                        var scoreRaisedElement = xmlDoc.querySelector('ScoreRaisedDueToHigherPreviousScore');
                        

                        try {
                            var scoreRaisedContent = scoreRaisedElement.textContent;
                            var integerscore = parseInt(scoreRaisedContent, 10);
                            if (integerscore > 80){
                                var scoreButton = document.getElementById('score');
                                    scoreButton.style.backgroundColor = 'green';
                                    scoreButton.textContent = 'All clear! System resources are operating optimally. 👍';
                            }else{
                                var scoreButton = document.getElementById('score');
                                    scoreButton.style.backgroundColor = 'red';
                                    scoreButton.textContent = 'Caution! System resources may not be providing sufficient performance. Performance issues may occur. 🚨';
                            }
    
                          } catch (error) {
                            var scoreButton = document.getElementById('score');
                            scoreButton.style.backgroundColor = 'red';
                            scoreButton.textContent = 'Caution! Unable to reach the overall component score. Please try again. 🚨';

                          }
                          















                        // Paragrafı içerik div'ine ekle                    
                        contentDiv.appendChild(paragraph); 
                        
                    }
                }
            }
        }
    };

}

// Sayfa yüklendiğinde system fonksiyonunu çağır
document.addEventListener('DOMContentLoaded', system);





/*      LİNUX OS    */
function findRootLinux() {
    var sourcePageElement = document.getElementById("source-Page");
    sourcePageElement.style.display = "block";
    // XML dosyasının URL'si
   var xmlURL = URL;
    // XMLHttpRequest nesnesini oluştur
    var xhr = new XMLHttpRequest();

    // GET isteği yap
    xhr.open('GET', xmlURL, true);

    // İsteği gönder
    xhr.send();

    // İstek tamamlandığında bu fonksiyon çalışacak
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // XML dosyasını işle
            var xmlDoc = xhr.responseXML;

            // XML içindeki tüm 'WinSAT' öğelerini seç

            

            var winSATElements = xmlDoc.getElementsByTagName('list');





            // Tablo gövdesini seç
            var tableBody = document.getElementById('tableBody');

            // Tek bir açılır menü düğmesi oluştur
            var button;
            if (!button) {
                button = document.createElement('button');
                button.innerHTML = 'More details';
            }


            // Her bir 'WinSAT' öğesi için döngü
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm çocukları al
                var children = winSATElements[i].children;

                // İçerik div'i oluştur
                var contentDiv = document.createElement('div');
                contentDiv.className = 'hidden';

                // Her bir çocuk için döngü
                for (var j = 0; j < children.length; j++) {
                    // Çocuğun tag ismini ve içeriğini al
                    var tagName = children[j].tagName;
                    var content = children[j].textContent;

                    // İçeriği maksimum 60 karaktere kısalt
                    if (content.length > 60) {
                        content = content.substring(0, 60) + '...';
                    }

                    // Etiket ve içeriği içeren bir paragraf oluştur
                    var paragraph = document.createElement('p');
                    paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                    // Paragrafı içerik div'ine ekle
                    contentDiv.appendChild(paragraph);

                    // Her bir çocuğun altındaki çocukları al
                    var nestedChildren = children[j].children;

                    // Her bir alt çocuk için döngü
                    for (var k = 0; k < nestedChildren.length; k++) {
                        // Alt çocuğun tag ismini ve içeriğini al
                        var nestedTagName = nestedChildren[k].tagName;
                        var nestedContent = nestedChildren[k].textContent;

                        // İçeriği maksimum 60 karaktere kısalt
                        if (nestedContent.length > 60) {
                            nestedContent = nestedContent.substring(0, 60) + '...';
                        }

                        // Alt çocuğu içeren bir paragraf oluştur
                        var nestedParagraph = document.createElement('p');
                        nestedParagraph.innerHTML = '<b> &nbsp &nbsp' + nestedTagName + ':</b> ' + nestedContent;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(nestedParagraph);

                        // Alt çocuğun altındaki çocukları al
                        var doubleNestedChildren = nestedChildren[k].children;

                        // Her bir double-alt çocuk için döngü
                        for (var m = 0; m < doubleNestedChildren.length; m++) {
                            // Double-alt çocuğun tag ismini ve içeriğini al
                            var doubleNestedTagName = doubleNestedChildren[m].tagName;
                            var doubleNestedContent = doubleNestedChildren[m].textContent;

                            // İçeriği maksimum 60 karaktere kısalt
                            if (doubleNestedContent.length > 60) {
                                doubleNestedContent = doubleNestedContent.substring(0, 60) + '...';
                            }

                            // Double-alt çocuğu içeren bir paragraf oluştur
                            var doubleNestedParagraph = document.createElement('p');
                            doubleNestedParagraph.innerHTML = '<b> &nbsp &nbsp &nbsp' + doubleNestedTagName + ':</b> ' + doubleNestedContent;

                            // Paragrafı içerik div'ine ekle
                            contentDiv.appendChild(doubleNestedParagraph);

                            // Double-alt çocuğun altındaki çocukları al
                            var tripleNestedChildren = doubleNestedChildren[m].children;

                            // Her bir triple-alt çocuk için döngü
                            for (var n = 0; n < tripleNestedChildren.length; n++) {
                                // Triple-alt çocuğun tag ismini ve içeriğini al
                                var tripleNestedTagName = tripleNestedChildren[n].tagName;
                                var tripleNestedContent = tripleNestedChildren[n].textContent;

                                // İçeriği maksimum 60 karaktere kısalt
                                if (tripleNestedContent.length > 60) {
                                    tripleNestedContent = tripleNestedContent.substring(0, 60) + '...';
                                }

                                // Triple-alt çocuğu içeren bir paragraf oluştur
                                var tripleNestedParagraph = document.createElement('p');
                                tripleNestedParagraph.innerHTML = '<b> &nbsp &nbsp &nbsp &nbsp' + tripleNestedTagName + ':</b> ' + tripleNestedContent;

                                // Paragrafı içerik div'ine ekle
                                contentDiv.appendChild(tripleNestedParagraph);
                            }
                        }
                    }
                }

                // Her 'WinSAT' öğesi için tek bir satır oluştur
                var row = tableBody.insertRow();
                var cell = row.insertCell(0);

                // Açılır menü düğmesini satıra ekle
                cell.appendChild(button.cloneNode(true));

                // Düğmeye tıklandığında içeriği göster/gizle
                cell.querySelector('button').addEventListener('click', function() {
                    contentDiv.classList.toggle('hidden');
                });

                // İçerik div'ini satıra ekle
                cell.appendChild(contentDiv);
            }
        }
    };
}


         // tableBody id'sine sahip elementi seç
         var tableBody = document.getElementById('tableBody');

         // tableBody'nin altındaki <tr> tag'larını seç
         var trElements = tableBody.getElementsByTagName('tr');
         
         // <tr> tag'larının sayısını al
         var rowCount = trElements.length;
         
         // Sayıyı alert ile göster
         alert('tableBody altındaki <tr> tag\'larının sayısı: ' + rowCount);

// Sayfa yüklendiğinde findRoot fonksiyonunu çağır
document.addEventListener('DOMContentLoaded', findRootLinux);





/* genel inceleme bitti özell */
function systemLinux() {
    var sourcePageElement = document.getElementById("source-Page");
    sourcePageElement.style.display = "block";
    var xmlURL = URL;
    //var xmlURL = 'WinSATP.xml';
    // XMLHttpRequest nesnesini oluştur
    var xhr = new XMLHttpRequest();

    // GET isteği yap
    xhr.open('GET', xmlURL, true);

    // İsteği gönder
    xhr.send();

    // İstek tamamlandığında bu fonksiyon çalışacak
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // XML dosyasını işle
            var xmlDoc = xhr.responseXML;

            // XML içindeki tüm 'WinSAT' öğelerini seç
            var winSATElements = xmlDoc.getElementsByTagName('list');

            // Her bir 'WinSAT' öğesi için döngü
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByClassName('system');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('system');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;

                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(paragraph);
                    }
                }
            }
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByClassName('memory');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('memory');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;

                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(paragraph);
                    }
                }
            }
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByClassName('processor');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('Monitors');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;

                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(paragraph);
                    }
                }
            }
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByClassName('network');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('Graphics');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;

                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(paragraph);
                    }
                }
            }
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByClassName('volume');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('Disk');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;

                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(paragraph);
                    }
                }
            }
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByClassName('WinSPR');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('WinSPR');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;
                        var integerValue = parseInt(content, 10);
                        var WinSPR = document.getElementById('WinSPR');
                        if (integerValue > 7.5) {
                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + '<b id="green">' + integerValue + '</b>';
                        } else {
                            var paragraph = document.createElement('p');
                            paragraph.innerHTML = '<b>' + tagName + ':</b> ' + '<b id="red">' + integerValue + '</b>';
                        }
                        var scoreRaisedElement = xmlDoc.querySelector('ScoreRaisedDueToHigherPreviousScore');
                        

                        try {
                            var scoreRaisedContent = scoreRaisedElement.textContent;
                            var integerscore = parseInt(scoreRaisedContent, 10);
                            if (integerscore > 80){
                                var scoreButton = document.getElementById('score');
                                    scoreButton.style.backgroundColor = 'green';
                                    scoreButton.textContent = 'All clear! System resources are operating optimally. 👍';
                            }else{
                                var scoreButton = document.getElementById('score');
                                    scoreButton.style.backgroundColor = 'red';
                                    scoreButton.textContent = 'Caution! System resources may not be providing sufficient performance. Performance issues may occur. 🚨';
                            }
    
                          } catch (error) {
                            var scoreButton = document.getElementById('score');
                            scoreButton.style.backgroundColor = 'red';
                            scoreButton.textContent = 'Caution! Unable to reach the overall component score. Please try again. 🚨';

                          }
                          















                        // Paragrafı içerik div'ine ekle                    
                        contentDiv.appendChild(paragraph); 
                        
                    }
                }
            }
        }
    };

}
// Sayfa yüklendiğinde findRoot fonksiyonunu çağır
document.addEventListener('DOMContentLoaded', findRootLinux);



/*          MACOS       */

function findRootMAC() {
    var sourcePageElement = document.getElementById("source-Page");
    sourcePageElement.style.display = "block";
    // XML dosyasının URL'si
   var xmlURL = URL;
    // XMLHttpRequest nesnesini oluştur
    var xhr = new XMLHttpRequest();

    // GET isteği yap
    xhr.open('GET', xmlURL, true);

    // İsteği gönder
    xhr.send();

    // İstek tamamlandığında bu fonksiyon çalışacak
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // XML dosyasını işle
            var xmlDoc = xhr.responseXML;

            // XML içindeki tüm 'WinSAT' öğelerini seç

            

            var winSATElements = xmlDoc.getElementsByTagName('WinSAT');





            // Tablo gövdesini seç
            var tableBody = document.getElementById('tableBody');

            // Tek bir açılır menü düğmesi oluştur
            var button;
            if (!button) {
                button = document.createElement('button');
                button.innerHTML = 'More details';
            }


            // Her bir 'WinSAT' öğesi için döngü
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm çocukları al
                var children = winSATElements[i].children;

                // İçerik div'i oluştur
                var contentDiv = document.createElement('div');
                contentDiv.className = 'hidden';

                // Her bir çocuk için döngü
                for (var j = 0; j < children.length; j++) {
                    // Çocuğun tag ismini ve içeriğini al
                    var tagName = children[j].tagName;
                    var content = children[j].textContent;

                    // İçeriği maksimum 60 karaktere kısalt
                    if (content.length > 60) {
                        content = content.substring(0, 60) + '...';
                    }

                    // Etiket ve içeriği içeren bir paragraf oluştur
                    var paragraph = document.createElement('p');
                    paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                    // Paragrafı içerik div'ine ekle
                    contentDiv.appendChild(paragraph);

                    // Her bir çocuğun altındaki çocukları al
                    var nestedChildren = children[j].children;

                    // Her bir alt çocuk için döngü
                    for (var k = 0; k < nestedChildren.length; k++) {
                        // Alt çocuğun tag ismini ve içeriğini al
                        var nestedTagName = nestedChildren[k].tagName;
                        var nestedContent = nestedChildren[k].textContent;

                        // İçeriği maksimum 60 karaktere kısalt
                        if (nestedContent.length > 60) {
                            nestedContent = nestedContent.substring(0, 60) + '...';
                        }

                        // Alt çocuğu içeren bir paragraf oluştur
                        var nestedParagraph = document.createElement('p');
                        nestedParagraph.innerHTML = '<b> &nbsp &nbsp' + nestedTagName + ':</b> ' + nestedContent;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(nestedParagraph);

                        // Alt çocuğun altındaki çocukları al
                        var doubleNestedChildren = nestedChildren[k].children;

                        // Her bir double-alt çocuk için döngü
                        for (var m = 0; m < doubleNestedChildren.length; m++) {
                            // Double-alt çocuğun tag ismini ve içeriğini al
                            var doubleNestedTagName = doubleNestedChildren[m].tagName;
                            var doubleNestedContent = doubleNestedChildren[m].textContent;

                            // İçeriği maksimum 60 karaktere kısalt
                            if (doubleNestedContent.length > 60) {
                                doubleNestedContent = doubleNestedContent.substring(0, 60) + '...';
                            }

                            // Double-alt çocuğu içeren bir paragraf oluştur
                            var doubleNestedParagraph = document.createElement('p');
                            doubleNestedParagraph.innerHTML = '<b> &nbsp &nbsp &nbsp' + doubleNestedTagName + ':</b> ' + doubleNestedContent;

                            // Paragrafı içerik div'ine ekle
                            contentDiv.appendChild(doubleNestedParagraph);

                            // Double-alt çocuğun altındaki çocukları al
                            var tripleNestedChildren = doubleNestedChildren[m].children;

                            // Her bir triple-alt çocuk için döngü
                            for (var n = 0; n < tripleNestedChildren.length; n++) {
                                // Triple-alt çocuğun tag ismini ve içeriğini al
                                var tripleNestedTagName = tripleNestedChildren[n].tagName;
                                var tripleNestedContent = tripleNestedChildren[n].textContent;

                                // İçeriği maksimum 60 karaktere kısalt
                                if (tripleNestedContent.length > 60) {
                                    tripleNestedContent = tripleNestedContent.substring(0, 60) + '...';
                                }

                                // Triple-alt çocuğu içeren bir paragraf oluştur
                                var tripleNestedParagraph = document.createElement('p');
                                tripleNestedParagraph.innerHTML = '<b> &nbsp &nbsp &nbsp &nbsp' + tripleNestedTagName + ':</b> ' + tripleNestedContent;

                                // Paragrafı içerik div'ine ekle
                                contentDiv.appendChild(tripleNestedParagraph);
                            }
                        }
                    }
                }

                // Her 'WinSAT' öğesi için tek bir satır oluştur
                var row = tableBody.insertRow();
                var cell = row.insertCell(0);

                // Açılır menü düğmesini satıra ekle
                cell.appendChild(button.cloneNode(true));

                // Düğmeye tıklandığında içeriği göster/gizle
                cell.querySelector('button').addEventListener('click', function() {
                    contentDiv.classList.toggle('hidden');
                });

                // İçerik div'ini satıra ekle
                cell.appendChild(contentDiv);
            }
        }
    };
}


         // tableBody id'sine sahip elementi seç
         var tableBody = document.getElementById('tableBody');

         // tableBody'nin altındaki <tr> tag'larını seç
         var trElements = tableBody.getElementsByTagName('tr');
         
         // <tr> tag'larının sayısını al
         var rowCount = trElements.length;
         
         // Sayıyı alert ile göster
         alert('tableBody altındaki <tr> tag\'larının sayısı: ' + rowCount);

// Sayfa yüklendiğinde findRoot fonksiyonunu çağır
document.addEventListener('DOMContentLoaded', findRootMAC);





/* genel inceleme bitti özell */
function systemMAC() {
    var sourcePageElement = document.getElementById("source-Page");
    sourcePageElement.style.display = "block";
    var xmlURL = URL;
    //var xmlURL = 'WinSATP.xml';
    // XMLHttpRequest nesnesini oluştur
    var xhr = new XMLHttpRequest();

    // GET isteği yap
    xhr.open('GET', xmlURL, true);

    // İsteği gönder
    xhr.send();

    // İstek tamamlandığında bu fonksiyon çalışacak
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // XML dosyasını işle
            var xmlDoc = xhr.responseXML;

            // XML içindeki tüm 'WinSAT' öğelerini seç
            var winSATElements = xmlDoc.getElementsByTagName('WinSAT');

            // Her bir 'WinSAT' öğesi için döngü
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByTagName('System');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('system');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;

                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(paragraph);
                    }
                }
            }
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByTagName('Memory');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('memory');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;

                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(paragraph);
                    }
                }
            }
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByTagName('Monitors');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('Monitors');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;

                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(paragraph);
                    }
                }
            }
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByTagName('Graphics');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('Graphics');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;

                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(paragraph);
                    }
                }
            }
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByTagName('Disk');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('Disk');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;

                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + content;

                        // Paragrafı içerik div'ine ekle
                        contentDiv.appendChild(paragraph);
                    }
                }
            }
            for (var i = 0; i < winSATElements.length; i++) {
                // Her bir 'WinSAT' öğesinin altındaki tüm 'System' öğelerini al
                var systemElements = winSATElements[i].getElementsByTagName('WinSPR');

                // İçerik div'idir ve her 'System' öğesi için sıfırlanır
                var contentDiv = document.getElementById('WinSPR');
                contentDiv.innerHTML = ''; // Her seferinde içeriği temizle

                // Her bir 'System' öğesi için döngü
                for (var j = 0; j < systemElements.length; j++) {
                    // 'System' öğesinin altındaki tüm çocukları al
                    var children = systemElements[j].children;

                    // Her bir çocuk için döngü
                    for (var k = 0; k < children.length; k++) {
                        // Çocuğun tag ismini ve içeriğini al
                        var tagName = children[k].tagName;
                        var content = children[k].textContent;
                        var integerValue = parseInt(content, 10);
                        var WinSPR = document.getElementById('WinSPR');
                        if (integerValue > 7.5) {
                        // Etiket ve içeriği içeren bir paragraf oluştur
                        var paragraph = document.createElement('p');
                        paragraph.innerHTML = '<b>' + tagName + ':</b> ' + '<b id="green">' + integerValue + '</b>';
                        } else {
                            var paragraph = document.createElement('p');
                            paragraph.innerHTML = '<b>' + tagName + ':</b> ' + '<b id="red">' + integerValue + '</b>';
                        }
                        var scoreRaisedElement = xmlDoc.querySelector('ScoreRaisedDueToHigherPreviousScore');
                        

                        try {
                            var scoreRaisedContent = scoreRaisedElement.textContent;
                            var integerscore = parseInt(scoreRaisedContent, 10);
                            if (integerscore > 80){
                                var scoreButton = document.getElementById('score');
                                    scoreButton.style.backgroundColor = 'green';
                                    scoreButton.textContent = 'All clear! System resources are operating optimally. 👍';
                            }else{
                                var scoreButton = document.getElementById('score');
                                    scoreButton.style.backgroundColor = 'red';
                                    scoreButton.textContent = 'Caution! System resources may not be providing sufficient performance. Performance issues may occur. 🚨';
                            }
    
                          } catch (error) {
                            var scoreButton = document.getElementById('score');
                            scoreButton.style.backgroundColor = 'red';
                            scoreButton.textContent = 'Caution! Unable to reach the overall component score. Please try again. 🚨';

                          }
                          















                        // Paragrafı içerik div'ine ekle                    
                        contentDiv.appendChild(paragraph); 
                        
                    }
                }
            }
        }
    };

}

// Sayfa yüklendiğinde system fonksiyonunu çağır
document.addEventListener('DOMContentLoaded', systemMAC);
