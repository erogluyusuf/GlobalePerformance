window.addEventListener('load', function() {
    runSpeedTest()
});





function dataPage(){
            // Bilgileri al
            var networkInfo = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
            var memoryInfo = window.performance.memory;
            var displayInfo = window.screen;

            // Güncellenmiş bilgileri hazırla
            var updatedInfo = '';

            // Ağ bilgileri
            if (networkInfo) {
                updatedInfo += 'Bağlantı Tipi: ' + networkInfo.effectiveType + '<br>';
                updatedInfo += 'İnternet Hızı: ' + networkInfo.downlink + ' Mbps' + '<br>';
            } else {
                updatedInfo += 'Ağ bilgilerine erişilemiyor.' + '<br>';
            }

            // Bellek bilgisi
            if (memoryInfo) {
                updatedInfo += 'Kullanılan Bellek: ' + memoryInfo.usedJSHeapSize + ' bayt' + '<br>';
            } else {
                updatedInfo += 'Bellek bilgilerine erişilemiyor.' + '<br>';
            }

            // Ekran bilgileri
            updatedInfo += 'Display: ' + displayInfo.width + ' X ' + displayInfo.height + ' piksel' + '<br>' + '(' + parseInt(displayInfo.width.toString().slice(0, 2)) + 'X' + parseInt(displayInfo.height.toString().slice(0,1)) + ')';

            // Bilgileri div içine yazdır
            document.getElementById('systemInfo').innerHTML = updatedInfo;
        }

       
        

        document.getElementById('speed').addEventListener('click', function() {
            runSpeedTest();
        });
        
        function runSpeedTest() {
            document.getElementById('speedalert').innerHTML = '<b style="text-align:center;">' + 'Please wait.' + '</b>';
        
            var fileSizeKB = 317; // İndirilecek dosyanın boyutu KB cinsinden
            var downloadURL = "https://www.fotopedi.org/wp-content/uploads/2014/02/yeni-fotograf-cekenler-5-kural.jpg"; // Değiştirilecek URL
        
            var startTime, endTime;
            var download = new Image();
        
            download.onload = function () {
                endTime = (new Date()).getTime();
                showDownloadResults(startTime, endTime, fileSizeKB);
            };
        
            download.onerror = function (err, msg) {
                console.log('Error during image load:', err, msg);
            };
        
            startTime = (new Date()).getTime();
            download.src = downloadURL + "?timestamp=" + new Date().getTime(); // Önbelleği önlemek için her seferinde benzersiz bir URL kullanın
        
            // Ping hesaplaması
            var pingStartTime = (new Date()).getTime();
            var pingImage = new Image();
            pingImage.onload = function () {
                var pingEndTime = (new Date()).getTime();
                var pingDuration = (pingEndTime - pingStartTime) / 2; // İki yönlü ping süresi
                showPingResults(pingDuration);
            };
            pingImage.src = "https://www.google.com/images/phd/px.gif" + "?timestamp=" + new Date().getTime(); // Önbelleği önlemek için benzersiz bir URL kullanın
        }
        
        function showDownloadResults(startTime, endTime, fileSizeKB) {
            var duration = (endTime - startTime) / 1000; // saniye cinsinden
            var downloadSpeed = (fileSizeKB / duration).toFixed(2); // KBps cinsinden
            document.getElementById('download').innerHTML = downloadSpeed + ' KBps';
            document.getElementById('network').innerHTML = downloadSpeed + 'KBps';
            control()
        }
        
        function showPingResults(pingDuration) {
            var pingSpeed = (pingDuration).toFixed(2); // ms cinsinden
            document.getElementById('ping').innerHTML = pingSpeed + ' ms';
            control()
        }
        

        
        
        
                  

   


        setInterval(dataPage, 1000);
document.addEventListener('DOMContentLoaded', dataPage);
document.addEventListener('DOMContentLoaded', function () {
    // DOM yüklendikten sonra
    // speedtest.js yüklenmiş mi kontrol et
    if (typeof Speedtest !== 'undefined') {
        runSpeedTest(); // Yüklenmişse hız testini başlat
    } else {
        console.error('Speedtest.js yüklenemedi.');
    }
});

function control(){
    var pingElement = document.getElementById('ping');
    var downloadElement = document.getElementById('download');
    
    if (pingElement.innerHTML.trim() !== '' && downloadElement.innerHTML.trim() !== '') {
        document.getElementById('speedalert').innerHTML = '<b style="text-align:center;">Completed.</b>';
    }
}


