// Batarya bilgisini alma fonksiyonu
function getBatteryInfo() {
    // navigator.getBattery() fonksiyonu bir Promise döndürür
    return navigator.getBattery()
      .then(function(battery) {
        // Batarya yüzdesini al
        var batteryPercentage = battery.level * 100;
        var battaryon = document.getElementById("on");
        var battaryoff = document.getElementById("off");
        // Bataryanın şarj durumunu kontrol et
        var charging = battery.charging;
        if(charging){
            battaryon.style.display = "none";
            battaryoff.style.display = "block";
        }else{
            battaryoff.style.display = "none";
            battaryon.style.display = "block";
        }
  
        // HTML'e yazdırma
        document.getElementById("battery").innerText = batteryPercentage + "%";
      })
      .catch(function(error) {
        console.error("Batarya bilgisi alınamadı:", error);
      });
  }
  
  // Sayfa yüklendiğinde batarya bilgisini al ve görüntüle
  document.addEventListener("DOMContentLoaded", function() {
    getBatteryInfo();
  });
  setInterval(getBatteryInfo, 1000);